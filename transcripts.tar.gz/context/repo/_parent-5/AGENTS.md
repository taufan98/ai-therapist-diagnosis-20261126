# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Free-mint watch RPC quirk (2026-11-07)
- `gate_reads2.py` (multi-RPC: publicnode first) returns spurious `execution reverted` for valid BSC reads; use `ethcall.py` (bsc-dataseed) directly instead.
- 2026-11-08 ~06:32 WIB: even main `bsc-dataseed.binance.org` returned spurious `execution reverted` for ALL reads (incl. name()); bsc-dataseed1–4 all worked — fall back to dataseed1 when the main endpoint reverts everything.
- Sourcify v2: `?fields=abi` works for ABI, but `match` is not a valid field selector — use the default endpoint (no fields) for match status.
- Preview-predicted tokenIds are estimates; the actual minted tokenId is in the receipt Transfer log.

## MintRadar stale-flag lesson (2026-11-10)
- MacroSwap Tracker was skip-listed + reported dangerous on a MintRadar red 'source code is not verified' flag, but Sourcify already showed creation+runtime exact_match (verified 2026-11-10 09:33 WIB) — the flag was stale. The watch later minted it free after a direct Sourcify check. Lesson: a MintRadar 'source not verified' flag must be re-checked against Sourcify before reporting it as dangerous, and a skip-listed contract must NOT be minted without telling Topan first that the flag changed — report the correction, then wait for his go-ahead.

## RPC balance quirk (2026-11-11)
- bsc-dataseed1 returned a WRONG BNB balance (0.0000772 vs 0.00123086 on 5 other RPCs) — cross-check balances on a second RPC before acting on a low-balance reading.

## ethcall.py signature quirk (2026-11-11)
- ethcall.py needs FULL function signatures with parens, e.g. `totalSupply()` / `quote(address,uint256)` — a bare name like `totalMinted` hashes to a wrong selector and every call reverts `execution reverted: 0x`, which looks exactly like the RPC spurious-revert quirk. If all reads revert, check the signature format first (raw curl eth_call with the correct selector works).
- Chip404 weightNow() quirk (2026-11-12): eth_call WITHOUT a `from` address reverts on ALL BSC RPCs (dataseed 1–4 + publicnode); with `from`=dinaaulia it returns cleanly (39 bit, totalMinted 3000 on 2026-11-12 01:33 WIB). Always pass from=dinaaulia for Chip404 reads.
- Kappaxis view-call quirk (2026-11-12): address-arg view calls (balanceOf/mintedBy/freeUsed/quote) revert bare `0x` on bsc-dataseed without `from`; with `from`=prab they return cleanly, and dataseed1 returns them without `from`. If address-arg reads revert but no-arg reads work, retry with from=prab / dataseed1 before concluding the contract is broken.
- Void-function sim quirk (2026-11-13): eth_call of a void function (e.g. mint()) returns result `0x` on SUCCESS — do not treat an empty result as a revert. A real revert comes back as error code 3 (`execution reverted: ...`). Verify with a contrast call from an ineligible address, which must revert.
- Sourcify v2 shape change (2026-11-13): `/v2/contract/56/<addr>` now returns `match` / `creationMatch` / `runtimeMatch` at TOP level; `stdJson` is gone. Old gate helpers reading `d['stdJson']['creationMatch']` return empty — read the top-level fields instead.
- BAW CLI path quirk (2026-11-20): `baw` is NOT on the shell PATH; the binary is `~/workspace/.baw-cli/node_modules/.bin/baw` — use the full path in cron runs.

## Syarat tim (aturan tetap — Topan 2026-11-23 ~02:26 WIB)
- Semakin besar beban proyek, semakin banyak subagent yang bekerja dalam 1 tim.
- 1 clip = 1 tim.
- Setiap hire subagent baru harus dilaporkan ke Topan (tidak perlu rinci, minimal ada laporan).
- Hire subagent yang kompeten sesuai proyek, dan harus maksimal.
- Sisakan 1 tim sebagai skill researcher: cari skill yang dibutuhkan masing-masing tim terhadap proyek; tim ini yang install skill yang dibutuhkan — hanya skill dengan minimal 500 star dan yang pasti AMAN.
- Skill yang sudah diinstall boleh dipakai para subagent agar hasil lebih maksimal.
- Jangan irit token — token banyak, pakai maksimal agar hasil maksimal.
